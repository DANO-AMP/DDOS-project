
		<ul class="profile"> 
			
                        <li>
				<a href="unset.php" class="btn-circle btn-sm">
					<i class="pe-7f-back"></i>
					
				</a>
			</li>
			<li>
				<a href="support.php" class="btn-circle btn-sm">
					<i class="pe-7f-mail"></i>
					<span class="badge badge--blue"><?php echo getUsersOpenedTickets(); ?></span>
					
				</a>
			</li>
			<li>
				<a href="profile.php" class="btn-circle btn-sm">
					<i class="pe-7g-sets"></i>
				</a>
			</li>
			
			
		</ul>

