
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">

<title>Obama Attacks | IP Stresser / Booter</title>

<meta name="description" content="Layer4 Stresser - Layer4 Stresser - Starting from 2 USD - Paypal!">
<meta name="keywords" content="Layer4 Stresser, Booter, DDoS, Layer7 Booter, Cheap DDoS Booter, Cheap Booter, Booter PayPal, Best Booter ">

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->

<link rel="stylesheet" href="assets/css/pre-loader.css">

<link rel="stylesheet" href="assets/css/bootstrap.css">

<link rel="stylesheet" href="assets/css/font-awesome.css">

<link rel="stylesheet" href="assets/css/owl.carousel.css">

<link rel="stylesheet" href="assets/css/animate.css">

<link rel="stylesheet" href="assets/css/magnific-popup.css">

<link rel="stylesheet" href="assets/css/style.css">
<link rel="stylesheet" href="assets/css/style-dark.css">

<link rel="stylesheet" href="assets/css/responsive.css">

<link href='https://fonts.googleapis.com/css?family=Roboto:400,500,700,300%7cRaleway:400,300,500,700,600' rel='stylesheet' type='text/css'>

<link rel="icon" href="img/web-hosting.ico">
<link rel="apple-touch-icon" href="images2/apple-touch-icon.png">
<link rel="apple-touch-icon" sizes="72x72" href="images2/apple-touch-icon-72x72.png">
<link rel="apple-touch-icon" sizes="114x114" href="images2/apple-touch-icon-114x114.png">

<script src="assets/js/modernizr-2.8.3.min.js"></script>
</head>
<body class="dark">
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-102222988-1', 'auto');
  ga('send', 'pageview');

</script>

<div class="preloader-wrapper">
<div>
<div class="preloader">
<i>.</i>
<i>.</i>
<i>.</i>
</div>
</div>
</div>

<section id="main-content">

<div id="banner" class="banner banner-left-text bg-style hero-banner">
<div id="background-carousel">
<div id="myCarousel" class="carousel slide" data-ride="carousel">
<div class="carousel-inner">
<div class="item item-no1 active"></div>
<div class="item item-no2"></div>
<div class="item item-no3"></div>
</div>
</div>
</div>
<div class="banner-content-wrapper">
 <div class="color-overlay">
<div class="container">
<div class="row">
<div class="col-md-7">
<div class="banner-logo m-bottom-60">
<a href="" title="HOPStresser.com"><img src="images2/logo-hop.png"  height="180" width="220" alt="logo" /></a>
</div>
<div class="banner-content wow animated fadeInUp" data-wow-duration="1.5s" data-wow-delay="0s">
<h1>Most reliable <br>IP Stresser / Booter</h1>
<p>New powerful IP Stresser / Booter</p>
<p>Compatible with any device.</p>
<div class="download-block">
<a class="btn" href="panel/login.php">Members Area</a>
</div>
</div>
</div>
<div class="col-md-5">
<div class="banner-mockup hidden-xs hidden-sm wow animated fadeInDown" data-wow-duration="1.5s" data-wow-delay="0s">
<img class="img-responsive" src="images2/1.png" height="649" width="358" alt="mockup" />
</div>
</div>
</div>
</div>
</div>
</div>
</div>


<div id="intro" class="intro section-padding">
<div class="container">
<div class="row">
<div class="heading-text-center m-bottom-80">
<h2 class="section-title">FEW WORDS ABOUT US.</h2>
<p class="section-sub-title">
We provide powerful layer 4 and 7 attacks!
</p>
<div class="separator"></div>
</div>
</div>
<div class="row">
<div class="col-md-4 col-sm-6">
<div class="intro-block text-center mb-sm-40 wow fadeInUp animated" data-wow-duration="1.5s" data-wow-delay="0s">

<h4>UNIQUE DESIGN</h4>
<p>
From our custom designed source, to our custom designed DDoS tool we guarantee you will enjoy unique quality we are offering.
</p>
</div>
</div>
<div class="col-md-4 col-sm-6">
<div class="intro-block text-center mb-sm-40 wow fadeInUp animated" data-wow-duration="1.5s" data-wow-delay="0.5s">

<h4>BUSINESS SOLUTION</h4>
<p>
We provide you with best web stress test on the market. With thousands of clients we are here to satisfy even the most power hungry customers.
</p>
</div>
</div>
<div class="col-md-4 col-sm-6">
<div class="intro-block text-center wow fadeInUp animated" data-wow-duration="1.5s" data-wow-delay="1s">

<h4>CUSTOMER SUPPORT</h4>
<p>
Our 24/7 customer support spread on over 3 different continents ensure your tickets being answered in 10-15 minutes. No other IP Stresser / Booter can guarantee this, but we do.
</p>
</div>
</div>
</div>
</div>
</div>


<div id="feature" class="feature section-padding">
<div class="container">
<div class="row">
<div class="col-md-6">
<div class="feature-mockup">
<img src="images2/2.png"  height="357" width="511" alt="image" class="feature-mockup-left img-responsive wow animated fadeInUp" data-wow-duration="1.5s">
</div>
</div>
<div class="col-md-6">
<div class="heading-text-left m-bottom-40">
<h2 class="section-title">CRAZY FEATURES</h2>
<p class="section-sub-title">
Our high performance dedicated servers ensures only strong stress tests.
With spoofed stress tests we take care of your privacy online.
</p>
<div class="separator"></div>
</div>
<div class="m-bottom-50">
<p class="sub-desc">
Our custom coded attack scripts, 24/7 customer service, Layer4 and Layer7 stress tests, Paypal autobuy.


</div>
<div class="item-lists">
<div>
<h5>Purchase using Paypal</h5>
<p>
We believe in huge potential of Paypal with paying online. Many other booters / IP Stressers don't have paypal enabled because they are scamming their customers.
</p>
<div>
<br>
<br>
<h5>Purchase with Bitcoin</h5>
<p>
By purchasing with bitcoin you automatically grant yourself a 15% discount. This beautifull crypto currency ensures complete privacy while paying online.
<br>
</div>
</div>
</div>
</div>
</div>
</div>


</div>
</div>
</div>
</div>
</div>
</div>


<div id="counter" class="counter bg-style banner-1">
<div class="color-overlay section-padding-small">
<div class="container">
<div class="row">
<div class="col-sm-3">
<div class="single-counter text-center">
<h2 class='numscroller numscroller-big-bottom' data-slno='1' data-min='60+' data-max='60+' data-delay='2' data-increment="1">$</h2>
<p>REGISTERED USERS</p>
</div>
</div>
<div class="col-sm-3">
<div class="single-counter text-center">
<h2 class='numscroller numscroller-big-bottom' data-slno='1' data-min='1800+' data-max='1800+' data-delay='5' data-increment="8">$</h2>
<p>STRESS TESTS</p>
</div>
</div>
<div class="col-sm-3">
<div class="single-counter text-center">
<h2 class='numscroller numscroller-big-bottom' data-slno='1' data-min='100+' data-max='100+' data-delay='3' data-increment="4">$</h2>
<p>STRESS TESTS PER DAY</p>
</div>
</div>
<div class="col-sm-3">
<div class="single-counter text-center">
<h2 class='numscroller numscroller-big-bottom' data-slno='1' data-min='3' data-max='3' data-delay='1' data-increment="1">$</h2>
<p>STAFF MEMBERS</p>
</div>
</div>
</div>
</div>
</div>
</div>


<div id="description" class="description section-top-padding">
<div class="container">
<div class="row">
<div class="heading-text-center m-bottom-80">
<h2 class="section-title">We strive to be the best!</h2>
<p class="section-sub-title">
Welcome to Obama Attacks! We hope you enjoy your stay with us.
</p>



</div>
</div>
</div>
</div>
</div>


<div id="pricing_table" class="pricing-table section-padding">
<div class="container">
<div class="row">
<div class="heading-text-center m-bottom-80">
<h2 class="section-title">PRICING TABLE</h2>
<p class="section-sub-title">
Below you can find some of our most purchased packages and information about it. To view a full list of packages please sign in to our site and click "Purchase".
</p>
<div class="separator"></div>
</div>
</div>
<div class="row">
<div class="col-md-3 col-sm-6">
<div class="price-block text-center wow animated fadeInUp" data-wow-duration="1.5s" data-wow-delay="0s">
<div class="price-header">

<h5>1 Day - TRIAL</h5>
</div>
<div class="price-plan">
<ul>
<li>1 Concurrents</li>
<li>120 Seconds boot time</li>
<li>1 Day Membership</li>
<li>Access to our DDoS tool.</li>
<li><a href="purchase.php" class="btn price-btn">1 $</a></li>
</ul>
</div>
</div>
</div>
<div class="col-md-3 col-sm-6">
<div class="price-block text-center wow animated fadeInUp" data-wow-duration="1.5s" data-wow-delay="0.5s">
<div class="price-header">
<h5>1 Month - Bronze</h5>
</div>
<div class="price-plan">
<ul>
<li>1 Concurrents</li>
<li>300 Seconds boot time</li>
<li>1 Month Membership</li>
<li>Access to our DDoS tool.</li>
<li>
<li><a href="purchase.php" class="btn price-btn">5 $ </a></li>
</a>
</li>
</ul>
</div>
</div>
</div>
<div class="col-md-3 col-sm-6">
<div class="price-block text-center wow animated fadeInUp" data-wow-duration="1.5s" data-wow-delay="1s">
<div class="price-header">
<h5>1 Month - Gold</h5>
</div>
<div class="price-plan">
<ul>
<li>1 Concurrents</li>
<li>600 seconds boot time</li>
<li>1 Month Membership</li>
<li>Access to our DDoS tool.</li>
<li><a href="purchase.php" class="btn price-btn">10 $ </a></li>
</ul>
</div>
</div>
</div>
<div class="col-md-3 col-sm-6">
<div class="price-block text-center wow animated fadeInUp" data-wow-duration="1.5s" data-wow-delay="1.5s">
<div class="price-header">
<h5>1 Month - Platinum</h5>
</div>
<div class="price-plan">
<ul>
<li>2 Concurrents</li>
<li>2200 Seconds boot time</li>
<li>1 Month Membership</li>
<li>Access to our DDoS tool.</li>
<li><a href="purchase.php" class="btn price-btn">15 $ </a></li>
</ul>
</div>
</div>
</div>
</div>
</div>
</div>





<script src="assets/js/jquery-1.11.3.min.js"></script>

<script src="assets/js/bootstrap.js"></script>

<script src="assets/js/jquery.ajaxchimp.min.js"></script>

<script src="assets/js/jquery.magnific-popup.js"></script>

<script src="assets/js/matchMedia.js"></script>
<script src="assets/js/jquery.stellar.js"></script>

<script src="assets/js/owl.carousel.js"></script>
<script src="assets/js/jquery.flexslider-min.js"></script>

<script src="assets/js/smoothscroll.js"></script>
<script src="assets/js/jquery.scrollTo.min.js"></script>
<script src="assets/js/jquery.localScroll.js"></script>
<script src="assets/js/jquery.nav.js"></script>
<script src="assets/js/counter.js"></script>
<script src="assets/js/wow.js"></script>
<script src="assets/js/custom.js"></script>
</html>
